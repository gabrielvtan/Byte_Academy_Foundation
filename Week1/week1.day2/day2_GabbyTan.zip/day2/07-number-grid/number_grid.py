## Day 2 - Exercise 7 - Number Grid

# Write a program that prints 10 lines, where each line has 10 numbers on it so that the numbers go
#from 0 to 99.
#0 1 2 3 4 5 6 7 8 9
#10 11 12...
# and so on.
for i in range(0,100,10):
    for j in range (0,10):
        print('{:3}'.format(i+j), end="")
    print("\n")



### Challenge problem:
#Accept an integer input. Make a rectangular grid with that many numbers. Try to make the grid as
#square as division will allow you to.