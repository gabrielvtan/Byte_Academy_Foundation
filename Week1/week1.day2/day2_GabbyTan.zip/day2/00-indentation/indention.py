print("Hello ", end="")
print("World!")