## Day 2 - Exercise 3 - Leap Year

#### When a year is a leap year.

* To adjust for the year not being an exact number of days, some years have an extra day, the 29th of September.

* A year is a leap year if it is divisible by 4.

* A year is not a leap year if it is also divisible by 100.

* But it is a leap year if it is divisible by 400y.

#### The assignment

* Write a program that prompts the user for a year.

* Print out a message if the year is a leap year and a message if it is not.

* There are different ways of combining ``` or ``` and ``` and ``` and ``` if ``` to do this test. Try to do it a few different ways.