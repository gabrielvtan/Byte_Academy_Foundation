## Day 1 Exercise 2 - Hello World

# Now we're going to test if your setup works.

# In VSCode write a one-line program that prints the string "Hello World!" and save it in this folder.

# Run it in your terminal to see that it works!