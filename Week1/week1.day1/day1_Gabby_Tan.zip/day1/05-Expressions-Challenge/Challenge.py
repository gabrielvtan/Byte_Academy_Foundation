# prompt user for hours & dollar rate
hours = input("Number of hours worked ")
wage = input("Hourly wage ")

salary = float(hours)*float(wage)
print(salary)